package com.kurdestan.snapfood.finalize_basket;

public enum Status {
     PAID,
    UNPAID
}
