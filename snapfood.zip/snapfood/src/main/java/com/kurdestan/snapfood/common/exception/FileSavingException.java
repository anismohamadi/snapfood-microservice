package com.kurdestan.snapfood.common.exception;
public class FileSavingException extends RuntimeException {
    public FileSavingException(String message) {
        super(message);
    }
}
