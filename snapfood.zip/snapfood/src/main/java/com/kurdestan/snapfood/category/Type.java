package com.kurdestan.snapfood.category;

public enum Type {
    RESTURANT,
    BAKERY,
    THECAFE,
    SWEETS,
    FRUIT,
    AGIL,
    OTHER
}
