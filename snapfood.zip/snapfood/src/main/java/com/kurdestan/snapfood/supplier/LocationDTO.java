package com.kurdestan.snapfood.supplier;

import lombok.Data;

@Data
public class LocationDTO {
    private  Double Lat;
    private  Double lng;
}
