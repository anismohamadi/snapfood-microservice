package com.kurdestan.snapfood.user;

import lombok.Data;

@Data
public class LocationDTO {
    private  Double Lat;
    private  Double lng;
}
