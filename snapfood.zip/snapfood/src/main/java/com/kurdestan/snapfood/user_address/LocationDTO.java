package com.kurdestan.snapfood.user_address;

import lombok.Data;

@Data
public class LocationDTO {
    private  Double Lat;
    private  Double lng;
}
